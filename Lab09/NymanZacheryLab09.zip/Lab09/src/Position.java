
public interface Position<E>
{
	public E getValue();

}
