/**
 * Project04
 * @author ZacheryNyman
 * 10 May 2017
 */

package ZacheryNyman;

public class Driver
{
	public static void main(String args[])
	{
		Window w = new Window();
	}
}
